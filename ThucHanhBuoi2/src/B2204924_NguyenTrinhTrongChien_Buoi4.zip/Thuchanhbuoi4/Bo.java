package Thuchanhbuoi4;

public class Bo extends ConVat{
	public void Keu() {
		System.out.println("Kêu: Ủm bòooooo");
	}
	
	public void NhapThongTin() {
		System.out.println("Hãy nhập thông tin cho Bò");
		super.NhapThongTin();
	}
	
	public void HienThongTin() {
		System.out.println("Thông tin cho Bò");
		super.HienThi();
	}
}
